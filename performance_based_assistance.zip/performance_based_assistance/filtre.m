function [ X_filt Y_filt ] = filtre( X,Y,fc,order,fs)
%FILTRE_POSITION 

%% filtre butterworth

X_filt = filtre_butter(fc,fs,order,X);
Y_filt = filtre_butter(fc,fs,order,Y);

end

