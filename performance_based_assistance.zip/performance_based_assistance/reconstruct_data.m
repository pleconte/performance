%% P.Leconte 14/06/2016

function [ output ] = reconstruct_data( dX,dY,dXosc,dYosc,omega_init,alpha_init,k_fluid ,fs,control,ReaplanOptions)
%RECONSTRUCT_DATA 
%  Computes the smoothness, velocity and amplitude errors and the gains of a
%  circular input signal
%  dX dY velocity profile of a circle [cm]
%  dXosc dYosc learned circle through adaptive oscillators[cm]
%  alpha_init is the initial amplitude, omega the initial omega but it can
%  also be a vector containing omega_osc

if nargin<10
    ReaplanOptions = 0;
end

omega_init = abs(omega_init);

dX    = dX'  ;
dY    = dY'   ;

error = sqrt((dX - dXosc).^2 + (dY - dYosc).^2)./omega_init ./alpha_init; 

derror_filt = 0;
k_fl_computed = 0;
k_vel_computed = 0;
k_amp_computed = 0;


err_min =0.09;
err_max = 0.20;

tho = 1;

alpha_filtre = 0.004;

if (length(omega_init)>1)
    real_time_control = 1;
else real_time_control = 0;
end
    omega_control = omega_init;

%% control made on error in velocity

if(strcmp(control,'velocity'))
    for i = 1:length(dX)-1
        
        if (real_time_control) 
            omega_init = omega_control(i);
            if (omega_init == 0)
                omega_init = 1;
            end
        end

        % compute smoothness error in real time
        if i< 5*fs  
            derror(i+1) = 0;
            derror_filt(i+1) = 0;
        else
            derror(i+1) = ((error(i+1) - error(i))*fs/omega_init);
            derror_filt(i+1) = derror_filt(i) + alpha_filtre*omega_init* (abs(derror(i+1))-derror_filt(i));
        end
        
        % compute gain fluidity
        k_fl_computed(i+1) = gain_tuner(derror_filt(i+1),k_fl_computed(i),tho,err_min,err_max,fs);
    
        % amplitude error
        error_amp(i+1) =  alpha_init(1) - alpha_init(i);
        % compute amplitude gain
        k_amp_computed(i+1) = gain_tuner(error_amp(i+1),k_amp_computed(i),tho,0,0.01,fs);
        
        % velocity error
        omega_d(i+1) = omega_control(1)*0.9; % desired frequency
        error_vel(i+1) = (omega_d(i)) - omega_control(i);
        % compute velocity gain
        k_vel_computed(i+1) = gain_tuner(error_vel(i+1),k_vel_computed(i),tho,0,0.1,fs);
    end
end

    output.meanError      = mean(derror_filt(end-(10+round((2*pi)/omega_init*fs)):end-10));
    output.derror         = derror;
    output.error_filt     = error;
    output.derror_filt    = derror_filt;
    output.k_fl_computed  = k_fl_computed;
    output.k_amp_computed = k_amp_computed;
    output.k_vel_computed = k_vel_computed;


end

%% gain tuner
function pct_k_out = gain_tuner(error,pct_k,tho,err_min,err_max,fs)
        dk = (1/err_max*(error-err_min) - pct_k);
        if error < err_min
            dk = -pct_k;
        end
        if (error >(err_max+err_min))
            dk = 1-pct_k;
        end
        
        pct_k_out = pct_k + (1/tho*dk)/fs;
        if pct_k_out<0
            pct_k_out = 0;
        end
        if pct_k_out>1
            pct_k_out = 1;
        end
end

