function X_filt = filtre_butter(fc,fs,order,X)


[B,A] = butter(order,2*fc/fs); % Niquist
X_filt = filtfilt(B,A,X);


end

