%% P.Leconte 14/06/2016


%% This script loads the results of the two patients with assistance and
%  without assistance and shows the experimental results exposed in the
%  paper "Performance-based robotic assistance during rhythmic arm
%  exercises" in figure 9

close all;
clear all;

% load patient results from the robot
load p_JNER.mat;

%% variables initialization
as = {'A','NA'}; % with assistance and without assistance

time_evaluation  = 29; % after 10 seconds of initialisation where no assistance was delivered
error_session    = zeros(10,time_evaluation*125,2); % session number (selon ordre) x time x patient_number
k_fluid_session  = zeros(10,time_evaluation*125,2); % session number (selon ordre) x time x patient_number
error_fluid_A    = zeros(5,time_evaluation*125,2);  % session  x time x patient_number
error_fluid_NA   = zeros(5,time_evaluation*125,2);  % session  x time x patient_number
meanWsession_abs = zeros(10,2);
stdWsession_abs  = zeros(10,2);

i                = 1;                              % counting all movements

%% experimental validation of smoothness metric

for num_patient = 1:2
    %reset variables
    num_sess     = 1;
    num_fluid_NA = 1;
    num_fluid_A  = 1;
    
   for num_assistance = 1:2
            assistance = as{num_assistance}
            for num = 1:5
                session = p_JNER(num_patient).(assistance)(num);
                
                % create matrix for performance evaluation with and without
                % assistance

                work_Fabs = 0;
                m = 1;
                
                for mvt = 1:numel(session.movements.M)
                    M = session.movements.M(mvt);                    
                    
                    if M.end_time>0 && M.end_time<40
                        work_Fabs(m) = M.W_Fabs;
                        i = i+1;
                        m = m+1;
                    end                    
                end
                
                % create matrix for slacking fluidity during session
                if (strcmp(assistance, 'A') )
                    
                    error_fluid_A(num_fluid_A,:,num_patient)  = session.mean_error(5*125+1:34*125)';
                    k_fluid_session(num_sess,:,num_patient)   = session.k_fluid(0*125+1:29*125)';                    
                    num_fluid_A = num_fluid_A+1;
                    
                elseif (strcmp(assistance, 'NA'))
                    error_fluid_NA(num_fluid_NA,:,num_patient) = session.mean_error(5*125+1:34*125)';
                    num_fluid_NA = num_fluid_NA+1;
                end
                
                    meanWsession_abs(num_sess,num_patient) = mean(work_Fabs/1000);
                    stdWsession_abs(num_sess,num_patient)  = std(work_Fabs/1000);
                    error_session(num_sess,:,num_patient)  = session.mean_error(5*125+1:34*125)';
                
                name_exo(num_sess,num_patient) = {strcat(assistance)};
                num_sess = num_sess+1     
            end
   end        
end

%% performance with and without assistance
figure
for i=1:2
anova1([mean(error_fluid_A(:,:,i)')' mean(error_fluid_NA(:,:,i)')'])
end


%% slacking fluidity over 1 session

for i=1:2
    exercice_ass_fluid = [1:5];
    figure, 
    subplot(2,1,1)
    plot(error_session(exercice_ass_fluid,:,i)','--'); hold on;
    plot(mean(error_session(exercice_ass_fluid,:,i)),'linewidth',2)
    legend('session 1', 'session 2', 'session 3', 'session 4', 'session 5')
    title (strcat('Evolution of the assistance and fluidity in patient',num2str(i),'over the session'))
    xlabel('time')
    ylabel('\epsilon_{fl}')
    subplot(2,1,2)
    plot(k_fluid_session(exercice_ass_fluid,:,i)','--');hold on;
    plot(mean(k_fluid_session(exercice_ass_fluid,:,i)),'linewidth',2)
    xlabel('time')
    ylabel('k_{fl}')
    legend('session 1', 'session 2', 'session 3', 'session 4', 'session 5')
end

%% slacking fluidity over 5 sessions
for i=1:2
figure,

    subplot(2,1,1)
    bar(mean(error_session(:,:,i)'),'y')
    hold on;
    for j=1:10 %session
       plot([j,j],[mean(error_session(j,:,i)')-std(error_session(j,:,i)'),...
           mean(error_session(j,:,i)')+std(error_session(j,:,i)')],'-k','LineWidth',2)
    end
    axis([0 16 0 0.018])
    ylabel('\epsilon_{fl}')
    title (strcat('Evolution of the assistance and fluidity in patient ',num2str(i),' over the 5 sessions'))
    set(gca,'XTickLabel',name_exo(:,i));
    h=gca
    subplot(2,1,2)
    bar(mean(k_fluid_session(:,:,i)'),'y')
    hold on;
    for j=1:10 %session
       plot([j,j],[mean(k_fluid_session(j,:,i)')-std(k_fluid_session(j,:,i)'),...
           mean(k_fluid_session(j,:,i)')+std(k_fluid_session(j,:,i)')],'-k','LineWidth',2)
    end
    axis([0 16 0 1])
    ylabel('k_{fl}')
    set(gca,'XTickLabel',name_exo(:,i));
    h=gca;
    
end

%% work

figure,
for i = 1:2
    subplot(2,1,i)
    bar(meanWsession_abs(:,i),'y')
    hold on;
    for j=1:10 %session
       plot([j,j],[meanWsession_abs(j,i)-stdWsession_abs(j,i),...
           meanWsession_abs(j,i)+stdWsession_abs(j,i)],'-k','LineWidth',2)
    end
    set(gca,'XTickLabel',name_exo(:,i));
    h=gca;
    title(strcat('work per movement over session for patient ',num2str(i)))
end

for i=1:2
    anova1([meanWsession_abs(1:5,i) meanWsession_abs(6:10,i)])
end


%% assistance proportional to error
figure
for i=1:2


    plot(mean(error_session(:,:,i)'),mean(k_fluid_session(:,:,i)'),'.')
    hold on
    axis([0 8e-3 0 1 ])
    xlabel('error')
    ylabel('k_{fluid}')
end



end