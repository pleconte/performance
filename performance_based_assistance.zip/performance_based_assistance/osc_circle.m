
%% P.Leconte 14/06/2016

function [Time Xvrai Yvrai OscX OscY dOscX dOscY out freq] = osc_circle(s,X,Y,T,fs,ReaplanOptions)
%% this function computes the adaptive oscillator for a 2D circular signal
% s contains the parameters of the adaptive oscillator
    % s(1) = tho_a
    % s(2) = tho_w
    % s(3) = frequency
    % s(4) = amplitude_init
    % s(5) = offset_X (center of circle)
    % s(6) = offset_Y (center of circle)
% X and Y input signal
% T 
% sample frequency
% ReaplanOptions = 1 when we use the parameters implemented on the robot

if (nargin<6)
    % options used on the robot
    ReaplanOptions = 0;
end

% Param�tres de l'oscillateur
dt = 1/fs;                                      % pas de temps 

parameters = ones(1,4);
parameters(1) = s(1);                           % tho_a
parameters(2) = s(2);                           % tho_w
parameters(3) = dt;                             % time step

% Initial condition of oscillator
POstate_in      = zeros(1,5); 
POstate_in(1,1) = X(1);                              % OffsetX
POstate_in(1,5) = Y(1);                              % OffsetY
if ReaplanOptions
    POstate_in(1,1) = s(5);
    POstate_in(1,5) = s(6);
end
POstate_in(1,2) = 2*pi*s(3);                         % Omega_init
POstate_in(1,8) = 0;                                 % Omega Y
POstate_in(1,3) = 0;                                 % Phi
POstate_in(1,7) = 0;                                 % phiY
if ReaplanOptions
   POstate_in(1,3) = pi/2;
end
POstate_in(1,4) = s(4);                              % AmplitudesX
POstate_in(1,6) = 0;   


t_final = length(Y);                                 % duration


out = zeros(t_final,length(POstate_in(1,:))); 

i = 1;

freq  = zeros(1,t_final);
posX  = zeros(1,t_final);
posY  = zeros(1,t_final);
error = zeros(1,t_final);
x     = zeros(1,t_final);
y     = zeros(1,t_final);

    for t = 1:t_final

        freq(i) = 1;    
        meas_pos = [X(t) Y(t)];
        posX(i) = X(t); 
        posY(i) = Y(t);
        if(ReaplanOptions==1 && t == 10*125) % after 5 seconds tho_w and tho_a = 10s
            parameters(1) = 10;
            parameters(2) = 10;
        end
        
        [out(i,:) err] = adaptive_osc(meas_pos,parameters,POstate_in',t,ReaplanOptions); 
        error(i+1) = err;


        POstate_in(1,:) = out(i,:); 
        
        time(i) = T(t); 
         

            x(i) = out(i,1) + out(i,4)*sin(out(i,3)');
            y(i) = out(i,5) + out(i,4)*sin(out(i,7)'); 
            
            dx(i) = out(i,4)*out(i,2) * cos(out(i,3)');
            dy(i) = out(i,6)*out(i,2) * cos(out(i,7)');

        
    i = i+1;    
    end
   
 
Yvrai = posY; 
Xvrai = posX; 
OscY = y; 
OscX = x;
Time = time; 

dOscY = dy;
dOscX = dx;


end

function [POstate_out error]= adaptive_osc(meas_pos,parameters,POstate_in,t,ReaplanOptions)

% This function implements a discretized version of the simple adaptive oscillator
% for periodic profiles

% inputs: - meas_pos is the measured position
%         - POstate_in is the current state of the main adaptive oscillator
%         - parameters is the parameters vector
% outputs: - POstate_out is the updated state of the main adaptive oscillator

%% nargins
if (nargin<5)
    ReaplanOptions = 0;
end
%% PARAMETERS

stime=parameters(3);    %stime


tho_a = parameters(1);
tho_w = parameters(2);
eta = 2/tho_a;
nu_f = 20/tho_w^2;
nu_p = sqrt(24.2*nu_f);

%% PHASE OSCILLATOR STATE

if(t==1)
    reset_learning = 0;
end

phi(1) = POstate_in(3,1);
phi(2) = POstate_in(7,1);
sinphi = sin(POstate_in(3,1));
cosphi = cos(POstate_in(3,1));
ampl(1)  = POstate_in(4,1);
ampl(2)  = POstate_in(4,1);
offset(1) = POstate_in(1);
offset(2) = POstate_in(5);


pond_cpX = 2*cosphi/ampl(1);  


%% ITERATION LOOP
    theta = pi/2;
    ampl(2) = ampl(1);

learning_error(1) = meas_pos(1,1) - offset(1) - (ampl(1)*sinphi);
learning_error(2) = meas_pos(1,2) - offset(2) - (ampl(1)*sin(phi(1)-theta));
for i=1:2
    dOffset(i) = learning_error(i) * (2*eta);
    if (ReaplanOptions==1) % no learning of the offset during the exercises
      dOffset(i) = 0;
    end
end

% we learn one amplitude and one frequency to learn the circle
dPhi(1)     = POstate_in(2) + nu_p * ( cos(phi(1))/ampl(1)*learning_error(1) + cos(theta-phi(1))/ampl(1) * learning_error(2));
dPhi(2) = 0;
dOmega(1)   = nu_f * (learning_error(1) * pond_cpX + learning_error(2) * cos(theta-phi(1))/ampl(1));
dOmega(2) = 0;
dAmpl(1) = eta * (learning_error(1) * sinphi) + eta * (learning_error(2) * sin(phi(1)-theta));
dAmpl(2) = 0;


dPOstate_out = [dOffset(1) ; dOmega(1) ; dPhi(1) ; dAmpl(1) ;...
                dOffset(2) ; dAmpl(2)  ; dPhi(2) ; dOmega(2)]; 

POstate_out = POstate_in + stime * dPOstate_out;


POstate_out(7,1) = POstate_out(3,1) - theta  ;  %phiY = phiX-pi/2 car cercle
POstate_out(6)   = POstate_out(4);    %amplitudeX = amplitude Y


error = sqrt(learning_error(1)^2+learning_error(2)^2);

end


