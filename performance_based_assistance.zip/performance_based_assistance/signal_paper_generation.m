%% P.Leconte 14/06/2016

% This script constructs figure 7 of the paper
% first the signal is constructed
% Next, reconstruct_data computes the errors in smoothness, amplitude and 
% velocity are computed in order to obtain the gains
% Finally the figure is plotted

close all;
clear all;

amp_d   = 5; %cm

omega_d = pi;
dt      = 0.008;
T       = 2*pi/omega_d; 
nb_T    = 5;

t_3T = 0:dt:T*nb_T;
t_1T = 0:dt:T;

%% different movements - ideal (X0) - small - slow - jerky amp - jerky long
% perfect movement
x_0 = amp_d*cos(omega_d*t_3T);
y_0 = amp_d*sin(omega_d*t_3T);


% small movement
amp_min = 3;

x_small = amp_min.*cos(omega_d*t_3T);
y_small = amp_min.*sin(omega_d*t_3T);

% slow movement
omega_min    = pi/1.5;
T_slow       = 2*pi/omega_min;

t_3T_slow = 0:dt:nb_T*T_slow;

x_slow = amp_d*cos(omega_min*t_3T_slow);
y_slow = amp_d*sin(omega_min*t_3T_slow);

% jerky lat
amp_lat_error = 1;
omega_lat     = omega_d*4;
[ x_lat y_lat dx dy dx_smooth dy_smooth t ] = circles_trajectories(T*nb_T,amp_d,...
    omega_d,0,0,amp_lat_error, omega_lat,0,dt,0);

% jerky long
nb_stops = 4;
dv       = 0.6*amp_d*omega_d;
[ x_long y_long dx dy dx_smooth dy_smooth t ] = circles_trajectories(T*nb_T,amp_d,...
    omega_d,nb_stops,dv,0, 0,0,dt,0);
 

%% adaptive oscillator validation
[ x_init y_init dx dy dx_smooth dy_smooth t ] = circles_trajectories(T*nb_T,amp_d,...
    omega_d,nb_stops,dv,amp_lat_error, omega_lat,0,dt,0);

param = [3 3 omega_d/(2*pi) amp_min 0 0 ]; % [tho_a tho_w freq ampl * * * * postpro]    
[t_init x_init y_init xosc yosc dOscX dOscY out freq ] = osc_circle(param,x_init,y_init,t,1/dt,1);



%% performance-based assistance validation
x = [x_0 x_0 x_small x_0 x_slow x_0 x_lat' x_0 x_long' x_0];
y = [y_0 y_0 y_small y_0 y_slow y_0 y_lat' y_0 y_long' y_0];

t = linspace(0,length(x)*dt,length(x));

kinematics = compute_kinematics(t',x',y',1/dt,0,1.5);
dx = kinematics(:,4);
dy = kinematics(:,5);



param = [3 3 omega_d/(2*pi) amp_d 0 0 0 0 0]; % [tho_a tho_w freq ampl * * * * postpro]    
[t a b xosc yosc dxosc dyosc out freq ] = osc_circle(param,x,y,t,1/dt,0);

output = reconstruct_data(dx'/100,dy'/100,dxosc'/100,dyosc'/100,out(:,2),out(:,4)/100,t,1/dt,'velocity')
   
derror         = output.derror;
error_filt     = output.error_filt;
derror_filt    = output.derror_filt;
k_fl_computed  = output.k_fl_computed;
k_amp_computed = output.k_amp_computed;
k_vel_computed = output.k_vel_computed;
omega_control  = out(:,2);
omega_init     = out(1,2);
alpha_init     = out(:,4)/100;

figure,
subplot(5,1,1)
plot(t,x,t,xosc,'linewidth',2)
axis([10 100 -6 6])
title(strcat('omega init = ',num2str(omega_init)))
subplot(5,1,3)
plot(t,k_fl_computed*100,t,k_amp_computed*100,t,k_vel_computed*100,'linewidth',2)
legend('k_{sm}','k_{amp}','k_{vel}')
axis([10 100 0 100])
subplot(5,1,2);
plot(t,dx,t, dxosc,'linewidth',2)
axis([10 100 -20 20])
legend('dX','dX_{osc}')
subplot(5,1,4);hold on;
plot(t,abs(derror),'b')
plot(t,derror_filt,'r','linewidth',2)
plot(t,error_filt,'g','linewidth',2)
legend('d\epsilon','d\epsilon_{filt}','\epsilon')
axis([10 100 0 1])
subplot(5,1,5)
plot(t,omega_control,t,alpha_init*100,'linewidth',2)
legend('omega','alpha')
axis([10 100 0 6])
