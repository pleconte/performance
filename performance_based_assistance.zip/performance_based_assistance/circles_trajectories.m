%% P.Leconte 14/06/2016

function [ x y dx dy dx_smooth dy_smooth t ] = circles_trajectories(time,...
    ampl, omega, nb_stops,dv, ampl_lat, freq_lat,acceleration,... 
    dt,drawing  )
%%CIRCLES_TRAJECTORIES 
% build a simulated jerky circular movement
% time is the duration in seconds of the signal
% ampl is the mean amplitud of the circle
% omega is the mean frequency of the circle
% nb_stops is the amount of arrests 
% dv is the amplitude of the longitudinal velocity errors
% ampl_lat is the amplitude of the lateral errors
% freq_lat is the frequency of the lateral errors
% acceleration is the amount of acceleration of the mean longitudinal
% velocity
% dt is the time step
% drawing is set to 1 to plot the signal
%%

if(nargin<1)
close all; clear all;
    time = 5;
    ampl = 0.6;
    omega = pi;
    ampl_lat = 0;
    nb_stops = 2;
    dv = omega*ampl;
    freq_lat = omega*4;
    acceleration = 0;
end
if(nargin<9)
    dt= 0.008;
end
if(nargin<10)
    drawing = 1;
end



t = 0:dt:time;
L = length(t);

%% longitudinal errors ====================================================
%  omega is the mean frequency
%  nb_stops are the amount of stops made over one period
%  time is the duration of the circle drawing
%%=========================================================================

n = nb_stops;
da = dv/(ampl*omega*n);
domega = da*sin(n*omega*t);

if(nb_stops == 0)
    domega = 0;
end

%% acceleration ===========================================================
if(acceleration>0)
    omega_acc = omega + acceleration * t;
    omega = omega_acc;
end

%% lateral errors =========================================================
dampl = ampl + ampl_lat*sin(freq_lat.*t);

x =   dampl .* cos(omega.*t+domega);
y =   dampl .* sin(omega.*t+domega);

x = x';
y = y';

% speed computation
dx = -(ampl*omega+dv*cos(n*omega*t)).*sin(omega*t+dv/(ampl*omega*n)*sin(n*omega*t));
dy =  (ampl*omega+dv*cos(n*omega*t)).*cos(omega*t+dv/(ampl*omega*n)*sin(n*omega*t));
if(n == 0)
   dx = -(ampl+ampl_lat*sin(freq_lat*t))*omega.*sin(omega*t)+ampl_lat*freq_lat*cos(freq_lat*t).*cos(omega*t);
   dy =  (ampl+ampl_lat*sin(freq_lat*t))*omega.*cos(omega*t)+ampl_lat*freq_lat*cos(freq_lat*t).*sin(omega*t);
end
dx = dx';dy=dy';
dx_smooth = - ampl*omega.*sin(omega*t);
dy_smooth =   ampl*omega.*cos(omega*t);


% animation
if(drawing)
    figure,

for i=1:125*5
plot(x(i:i+125),y(i:i+125),x(i+125),y(i+125),'o');
    axis equal
    axis([-2 2 -2 2])
pause(0.01)
end
end

end

