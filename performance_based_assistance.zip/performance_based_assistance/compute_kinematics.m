%% P.Leconte 14/06/2016

function [ kinematics ] = compute_kinematics(T, X,Y,fs,plotting,fc )
%COMPUTE_KINEMATICS
%   computes the speed (vX, vY), acceleration (aX, aY) and jerk (jX, jY)
%   and return it in "kinematics = [X Y vX vY aX aY jX jY]"
if nargin<6
    fc = 5;
end
%% local variables
order = 2;

%% filter position with a butterworth

[ X_filt Y_filt ] = filtre( X,Y,fc,order,fs);

%% compute speed
 vx = diff(X_filt)*fs;
 vx(end+1)=0;
 vy = diff(Y_filt)*fs;
 vy(end+1)=0;
 
%% compute acceleration
  ax = diff(vx)*fs;
  ax(end+1)=0;
  ay = diff(vy)*fs;
  ay(end+1)=0;
  
%% compute jerk
 jx = diff(ax)*fs;
 jx(end+1)=0;
 jy = diff(ay)*fs;
 jy(end+1)=0;
 

%% return kinematics
kinematics = [T X Y vx vy ax ay jx jy];

if(plotting)
    
    subplot(3,1,1)
    plot([X Y])
    subplot(3,1,2)
    plot([vx vy])
    subplot(3,1,3)
    plot([ax ay])

end
end
