%% P.Leconte 14/06/2016


%% 
%  This script quantifies the real-time fluidity of a circle in function of 
%  - the amplitude of the movement
%  - the frequency of the movement
%  - the lateral error
%  - the longitudinal error
%  - the fluid acceleration of the movement
% The script plots Figure 6 of the paper
% =========================================================================

close all
clear all

%% initialize variables
alpha        = linspace(4,10,4);
omega        = linspace(pi/2, pi*3,4);
stops        = 0:5;
dalpha       = linspace(0,0.5,5);
freq_dalpha  = linspace(0,4,5);
dvitesse     = linspace(0,0.5,5);

time  = 20;
dt    = 0.008; 
na    = 1;
ns    = 1;
nw    = 1;
nda   = 1;
nf_da = 1;
nsa   = 1;

% initialize matrix which will contain the smoothness error (derror_filt) in function of 
% omega and alpha
impact_stops       = zeros(length(alpha),length(omega),length(stops));
impact_dalpha      = zeros(length(alpha),length(omega),length(dalpha));
impact_freq_dalpha = zeros(length(alpha),length(omega),length(freq_dalpha));
impact_domega      = zeros(length(alpha),length(omega),length(freq_dalpha));

 

%% Impact of the amplitude and frequency of the movement


for a = alpha
    
    for w =omega
        %% Impact of freq longitudinal errors
        for s = stops
           
            da = 0;
            f_da = 0;
            dv = dvitesse(2)*a*w;
            % build simulated circle trajectories 
            [ x y dx dy dx_smooth dy_smooth t ] = circles_trajectories(time, a, w, s,...
                        dv, da, f_da,0,...
                        dt,0);   
            % parameters of adaptive oscillator
            param = [3 3 w/(2*pi) a 0 0]; % [tho_a tho_w freq ampl * * ]         
            % adaptive oscillator 
            [t X Y Xosc Yosc dOscX dOscY out freq] = osc_circle(param,x,y,t,1/dt);
            % compute smoothness error based
            d_error_filt  = reconstruct_data((dx/100)',(dy/100)',(dOscX/100)',(dOscY/100)',out(:,2),out(:,4),t ,1/dt,'velocity');            
            % save result in matrix
            impact_stops(na,nw,ns) = d_error_filt.meanError;
            
            ns = ns+1;
         end
        %% Impact of amplitude longitudinal errors
        for Xv = dvitesse % pct velocity error
            
            nb_stops = 4 ;
            dv = Xv*a*w;
            da = 0;
            f_da = 0;
            % build simulated circle trajectories 
            [ x y dx dy dx_smooth dy_smooth t ] = circles_trajectories(time, a, w, nb_stops,...
                        dv, da, f_da,0,...
                        dt,0);
            % parameters of adaptive oscillator
            param = [3 3 w/(2*pi) a 0 0 ]; % [tho_a tho_w freq ampl * * ] 
            % adaptive oscillator 
            [t X Y Xosc Yosc dOscX dOscY out freq] = osc_circle(param,x,y,t,1/dt);
            % compute smoothness error based
            d_error_filt  = reconstruct_data( (dx/100)',(dy/100)',(dOscX/100)',(dOscY/100)',out(:,2),out(:,4),t ,1/dt,'velocity');
            % save result in matrix
            impact_domega(na,nw,nsa) = d_error_filt.meanError;
            
            nsa = nsa+1;
        end
        
        %% impact of amplitude of lateral errors
        for da = dalpha
            s = 0;
            f_da = w*4;
            err_lat = a*da;
            % build simulated circle trajectories 
            [ x y dx dy dx_smooth dy_smooth t ] = circles_trajectories(time, a, w, s,...
                        100, err_lat, f_da,0,...
                        dt,0);           
            % parameters of adaptive oscillator
            param = [3 3 w/(2*pi) a 0 0]; % [tho_a tho_w freq ampl * * ] 
            % adaptive oscillator 
            [t X Y Xosc Yosc dOscX dOscY out freq] = osc_circle(param,x,y,t,1/dt);
            % compute smoothness error based
            d_error_filt  = reconstruct_data( (dx/100)',(dy/100)',(dOscX/100)',(dOscY/100)',out(:,2),out(:,4),t ,1/dt,'velocity');
            % save result in matrix
            impact_dalpha(na,nw,nda) = d_error_filt.meanError;
            
            nda = nda +1;
        end
        
        %% impact of frequency of lateral errors
        for pct_f_da = freq_dalpha
            s = 0;
            da = a*0.1;
            f_da = pct_f_da * w;
            % build simulated circle trajectories 
            [ x y dx dy t ] = circles_trajectories(time, a, w, s,...
                        100, da, f_da,0,...
                        dt,0);       
            % parameters of adaptive oscillator
            param = [3 3 w/(2*pi) a 0 0]; % [tho_a tho_w freq ampl * *] 
            % adaptive oscillator 
            [t X Y Xosc Yosc dOscX dOscY out freq] = osc_circle(param,x,y,t,1/dt);
            % compute smoothness error based
            d_error_filt  = reconstruct_data( (dx/100)',(dy/100)',(dOscX/100)',(dOscY/100)',out(:,2),out(:,4),t ,1/dt,'velocity');
            % save result in matrix
            impact_freq_dalpha(na,nw,nf_da) = d_error_filt.meanError;
            
            nf_da = nf_da+1;
        end
        
        nw    = nw+1;
        ns    = 1;
        nf_da = 1;
        nda   = 1;
        nsa = 1;
     
    end
    na = na+1;
    nw = 1;
end

%% plot results

figure,
surf(omega, alpha, impact_freq_dalpha(:,:,1)); hold on;
surf(omega, alpha, impact_freq_dalpha(:,:,2)); hold on;
surf(omega, alpha, impact_freq_dalpha(:,:,3)); hold on;
surf(omega, alpha, impact_freq_dalpha(:,:,4)); hold on;
surf(omega, alpha, impact_freq_dalpha(:,:,5)); hold on;
legend(num2str(freq_dalpha(1)),num2str(freq_dalpha(2)),num2str(freq_dalpha(3)),num2str(freq_dalpha(4)))
xlabel('omega [rad/s]')
ylabel('alpha [cm]')
zlabel('error')
title('impact of frequency of lateral errors with 10% alpha')

figure,
surf(omega, alpha, impact_dalpha(:,:,1)); hold on;
surf(omega, alpha, impact_dalpha(:,:,2)); hold on;
surf(omega, alpha, impact_dalpha(:,:,3)); hold on;
surf(omega, alpha, impact_dalpha(:,:,4)); hold on;
xlabel('omega [rad/s]')
ylabel('alpha [cm]')
zlabel('error')
legend(num2str(dalpha(1)),num2str(dalpha(2)),num2str(dalpha(3)),num2str(dalpha(4)))
title('impact of magnitude of lateral errors at a n_{lat} = 4')


figure,
surf(omega, alpha, impact_stops(:,:,1)); hold on;
surf(omega, alpha, impact_stops(:,:,2)); hold on;
surf(omega, alpha, impact_stops(:,:,3)); hold on;
surf(omega, alpha, impact_stops(:,:,4)); hold on;
xlabel('omega [rad/s]')
ylabel('alpha [cm]')
zlabel('error')
legend(num2str(stops(1)),num2str(stops(2)),num2str(stops(3)),num2str(stops(4)))
title('impact of n_{long} with a longitudinal error of 20%')

figure,
surf(omega, alpha, impact_domega(:,:,1)); hold on;
surf(omega, alpha, impact_domega(:,:,2)); hold on;
surf(omega, alpha, impact_domega(:,:,3)); hold on;
surf(omega, alpha, impact_domega(:,:,4)); hold on;
xlabel('omega [rad/s]')
ylabel('alpha [cm]')
zlabel('error')
legend(num2str(dvitesse(1)),num2str(dvitesse(2)),num2str(dvitesse(3)),num2str(dvitesse(4)))
title('impact of error in velocity proportional to longitudinal velocity with n_{long} = 4')
